#!/bin/sh

ros install cxxxr/lem cxxxr/cl-lsp
