#!/bin/sh

set -e

"$(dirname "$0")/go_install.sh" github.com/lighttiger2505/sqls@latest
