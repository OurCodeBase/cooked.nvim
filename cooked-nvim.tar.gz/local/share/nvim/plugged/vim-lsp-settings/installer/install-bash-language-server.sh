#!/bin/sh

set -e

"$(dirname "$0")/npm_install.sh" bash-language-server bash-language-server
