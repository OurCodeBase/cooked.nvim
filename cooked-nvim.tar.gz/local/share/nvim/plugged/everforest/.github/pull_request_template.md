### Description

<!--
Link any issue if valid. Example: `Fixes #(issue)`

If creating a new theme, make sure to include a README.md and update the Wiki page to reference the new theme.

If fixing a theme, please describe why the change was made.
-->

### Screenshots

<!-- Please include any screenshots that are relevant to the pull request. -->
